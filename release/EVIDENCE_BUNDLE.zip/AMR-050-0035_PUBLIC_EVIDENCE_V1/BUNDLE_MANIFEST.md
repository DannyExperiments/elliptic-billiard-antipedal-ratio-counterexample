# Public evidence bundle manifest

Bundle ID: `AMR-050-0035_PUBLIC_EVIDENCE_V1`.

Every member is a regular file with fixed timestamp and mode.
`BUNDLE_SHA256SUMS.txt` hashes every member except itself.

## Members

- `AI_DISCLOSURE.md`
- `BUNDLE_MANIFEST.md`
- `BUNDLE_SHA256SUMS.txt`
- `CITATION.cff`
- `CLAIMS_EVIDENCE_MATRIX.md`
- `CONTRIBUTING.md`
- `LICENSE_STATUS.md`
- `PROBLEM_AND_PROOF.md`
- `PROVENANCE.md`
- `README.md`
- `REPLAY_README.md`
- `REPRODUCIBILITY.md`
- `SECURITY.md`
- `STATUS.md`
- `audits/README.md`
- `audits/public_safe_reports/IMPLICATIONS_SCOPE_SUMMARY.md`
- `audits/public_safe_reports/LITERATURE_STATUS_SUMMARY.md`
- `audits/public_safe_reports/MATHEMATICAL_AUDIT_SUMMARY.md`
- `audits/public_safe_reports/REPOSITORY_TEMPLATE_AND_PRIVACY_AUDIT_2026-08-12.md`
- `canonical/CANONICAL_CLAIM.md`
- `canonical/DEPENDENCY_MAP.md`
- `canonical/SCOPE_LIMITATIONS.md`
- `evidence/N8_SUPPORTING_LINE_CERTIFICATE.zip`
- `evidence/N8_SUPPORTING_LINE_CERTIFICATE.zip.sha256`
- `evidence/README.md`
- `formalization/README.md`
- `formalization/THEOREM_SCOPE.md`
- `formalization/aristotle/README.md`
- `formalization/lean/AXIOM_REPORT.txt`
- `formalization/lean/AxiomAudit.lean`
- `formalization/lean/K607FiniteCertificate.lean`
- `formalization/lean/README.md`
- `formalization/lean/SCOPE_BOUNDARY.md`
- `formalization/lean/lake-manifest.json`
- `formalization/lean/lakefile.toml`
- `formalization/lean/lean-toolchain`
- `paper/BUILD.md`
- `paper/BUILD_STATUS.md`
- `paper/CHANGELOG_FROM_CANONICAL_PROOF.md`
- `paper/CLAIM_SCOPE_AND_LIMITATIONS.md`
- `paper/PDF_PREFLIGHT.md`
- `paper/README.md`
- `paper/SOURCE_TO_CANONICAL_COMPARISON.md`
- `paper/manuscript.pdf`
- `paper/manuscript.tex`
- `paper/references.bib`
- `release/BADGE_ACTIVATION.md`
- `release/BRANCH_PROTECTION.md`
- `release/DOI_DEPOSIT.md`
- `release/HUMAN_RELEASE_CHECKLIST.md`
- `release/README.md`
- `release/RELEASE_NOTES_v1.0.0.md`
- `verification/EXPECTED_K607_STDLIB.txt`
- `verification/README.md`
- `verification/REPLAY_ACTUAL.txt`
- `verification/REPLAY_RECEIPT.md`
- `verification/verify_k607_stdlib.py`
