# Replay the public evidence bundle

This deterministic archive is an allowlisted public-safe evidence subset. It
contains no raw conversation, private receipt, local path, credential,
personal identifier, screenshot, or third-party source PDF. After extraction,
enter the AMR-050-0035_PUBLIC_EVIDENCE_V1 directory and run:

```bash
sha256sum -c BUNDLE_SHA256SUMS.txt
python3 -B verification/verify_k607_stdlib.py
```

These checks establish the archived bytes and finite exact certificate. They
do not replace the analytic proof, mathematical review, peer review, source
interpretation, priority search, or the explicitly partial Lean boundary.
