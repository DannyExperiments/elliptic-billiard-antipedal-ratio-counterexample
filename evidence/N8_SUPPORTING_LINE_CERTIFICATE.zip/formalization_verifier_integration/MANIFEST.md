# Public-safe formalization/verifier integration manifest

Target: `AMR-050-0035` / arXiv-v11 source-table row `k_607`  
Construction: canonical exact `N=8` supporting-line witness  
Status: `PREPARED_NOT_INTEGRATED_NOT_RELEASED`  
Private materials included: none

| Path | Purpose |
|---|---|
| `formalization/lean/K607FiniteCertificate.lean` | Finite exact Lean certificate. |
| `formalization/lean/AxiomAudit.lean` | Exported-theorem axiom audit. |
| `formalization/lean/AXIOM_REPORT.txt` | Frozen expected axiom output. |
| `formalization/lean/lean-toolchain` | Lean 4.30.0 pin. |
| `formalization/lean/lakefile.toml` | Zero-dependency Lake configuration. |
| `formalization/lean/lake-manifest.json` | Frozen zero-package manifest. |
| `verification/verify_k607_stdlib.py` | Independent fail-closed exact replay using only Python's standard library. |
| `verification/EXPECTED_K607_STDLIB.txt` | Frozen byte-exact expected replay output. |
| `.github/workflows/lean-finite-certificate.yml` | Pinned Lean build, kernel, axiom, and no-escape checks. |
| `.github/workflows/replay-exact-verifier.yml` | Pinned Python normal/optimized exact replay. |
| `README.md` | Public replay instructions and status. |
| `SCOPE_BOUNDARY.md` | Exact permitted and forbidden claims. |
| `INTEGRATION_NOTES.md` | Repository-relative handoff and gate order. |
| `MANIFEST.md` | This complete permanent-member inventory. |
| `SHA256SUMS.txt` | Per-file integrity ledger; intentionally excludes itself. |

Generated `.lake/`, `__pycache__/`, and replay `*.actual.txt` products are not
permanent package members and must not be committed.
