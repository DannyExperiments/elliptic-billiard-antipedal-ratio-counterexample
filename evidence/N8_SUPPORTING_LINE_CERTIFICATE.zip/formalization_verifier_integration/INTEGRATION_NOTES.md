# Public integration notes

## Intended repository-relative placement

Merge the contents of this directory at repository root, preserving these
paths exactly:

```text
.github/workflows/lean-finite-certificate.yml
.github/workflows/replay-exact-verifier.yml
formalization/lean/
verification/
README.md
SCOPE_BOUNDARY.md
MANIFEST.md
SHA256SUMS.txt
```

The workflow path assumptions are therefore deterministic.  If the recipient
repository already has a root `README.md`, integrate the bounded language
manually rather than overwriting unrelated content; the workflow and artifact
paths should remain unchanged.

## Gate order after integration

1. verify `SHA256SUMS.txt`;
2. build the pinned zero-package Lean project;
3. run `leanchecker` on `K607FiniteCertificate`;
4. compare fresh `#print axioms` output byte-for-byte with
   `formalization/lean/AXIOM_REPORT.txt`;
5. reject proof escapes, user axioms, native decision oracles, unsafe
   declarations, and unlimited heartbeat settings;
6. run the independent verifier normally and under `python -O`;
7. compare both outputs byte-for-byte with the expected output.

This staging package is prepared only.  It has not been copied into an active
release worktree, committed, pushed, published, badged, or attached to a
release.
