# Finite exact certificate and independent replay

This public-safe staging package contains two independently executable checks
for the canonical exact `N=8` **supporting-line** witness associated with
AMR-050-0035 and arXiv-v11 source-table row `k_607`:

1. `formalization/lean/` — a dependency-free Lean 4 finite exact coefficient
   certificate;
2. `verification/` — a fail-closed Python-standard-library reconstruction in
   the same exact algebra, with byte-frozen expected output.

They corroborate finite witness arithmetic.  They do not formalize or decide
the entire source problem.  Read `SCOPE_BOUNDARY.md` before quoting either
result.

## Local replay

With Lean 4.30.0 already available:

```sh
cd formalization/lean
lake build
lake env leanchecker K607FiniteCertificate
lake env lean AxiomAudit.lean > AXIOM_REPORT.actual.txt
diff -u AXIOM_REPORT.txt AXIOM_REPORT.actual.txt
cd ../..
```

With Python 3.11 or another current CPython using only its standard library:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B verification/verify_k607_stdlib.py > verification/REPLAY.actual.txt
diff -u verification/EXPECTED_K607_STDLIB.txt verification/REPLAY.actual.txt
PYTHONDONTWRITEBYTECODE=1 python3 -O -B verification/verify_k607_stdlib.py > verification/REPLAY.optimized.actual.txt
diff -u verification/EXPECTED_K607_STDLIB.txt verification/REPLAY.optimized.actual.txt
```

Verify the frozen integration inventory from this directory with:

```sh
shasum -a 256 -c SHA256SUMS.txt
```

The workflow specifications under `.github/workflows/` pin both third-party
actions by full commit SHA, give the GitHub token read-only content access,
disable checkout credential persistence, and run the exact scope gates above.

## Status

```text
LEAN_FINITE_CERTIFICATE: PASS
INDEPENDENT_STDLIB_REPLAY: PASS
FORMALIZATION: PARTIAL
FULL_SOURCE_THEOREM_FORMALIZED: NO
PUBLIC_RELEASE_ACTION: NOT_PERFORMED
```
